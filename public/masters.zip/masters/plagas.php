<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`plagas` */
$plagas = array(
  array('id' => '2','nombre_cientifico' => 'Polilla','nombre_comun' => 'Polilla','user_id' => '1','created_at' => '2019-01-30 21:29:38','updated_at' => '2019-01-30 21:29:38'),
  array('id' => '3','nombre_cientifico' => 'Mus musculus','nombre_comun' => 'Raton','user_id' => '1','created_at' => '2019-01-30 21:29:53','updated_at' => '2019-01-30 21:29:53'),
  array('id' => '4','nombre_cientifico' => 'Musca domestica','nombre_comun' => 'Mosca domestica','user_id' => '1','created_at' => '2019-01-30 21:30:36','updated_at' => '2019-11-02 03:13:41'),
  array('id' => '5','nombre_cientifico' => 'Mosca Azul','nombre_comun' => 'Mosca Azul','user_id' => '1','created_at' => '2019-01-30 21:30:52','updated_at' => '2019-01-30 21:30:52'),
  array('id' => '6','nombre_cientifico' => 'Mosca blanca','nombre_comun' => 'Mosca Blanca','user_id' => '1','created_at' => '2019-01-30 21:31:07','updated_at' => '2019-01-30 21:31:07'),
  array('id' => '7','nombre_cientifico' => 'Avispas','nombre_comun' => 'Avispas','user_id' => '1','created_at' => '2019-02-09 04:05:01','updated_at' => '2019-02-09 04:05:01'),
  array('id' => '8','nombre_cientifico' => 'Mosca de la fruta','nombre_comun' => 'Mosca de la fruta','user_id' => '1','created_at' => '2019-02-09 04:05:29','updated_at' => '2019-02-09 04:05:29'),
  array('id' => '9','nombre_cientifico' => 'Gecko','nombre_comun' => 'Gecko','user_id' => '1','created_at' => '2019-02-09 04:09:09','updated_at' => '2019-02-09 04:09:09'),
  array('id' => '10','nombre_cientifico' => 'Zancudos','nombre_comun' => 'Zancudos','user_id' => '1','created_at' => '2019-02-10 02:28:00','updated_at' => '2019-02-10 02:28:00'),
  array('id' => '11','nombre_cientifico' => 'Mariposas varios','nombre_comun' => 'Mariposas','user_id' => '1','created_at' => '2019-04-04 22:00:42','updated_at' => '2019-04-04 22:00:42'),
  array('id' => '12','nombre_cientifico' => 'Chinche comun','nombre_comun' => 'Chinche comun','user_id' => '1','created_at' => '2019-05-06 21:39:25','updated_at' => '2019-05-06 21:39:25'),
  array('id' => '13','nombre_cientifico' => 'Mosca Verde','nombre_comun' => 'Mosca Verde','user_id' => '1','created_at' => '2019-05-12 02:13:50','updated_at' => '2019-05-12 02:13:50'),
  array('id' => '14','nombre_cientifico' => 'Libelula','nombre_comun' => 'Libelula','user_id' => '1','created_at' => '2019-06-13 03:34:06','updated_at' => '2019-06-13 03:34:06'),
  array('id' => '15','nombre_cientifico' => 'Hormiga alada','nombre_comun' => 'Hormiga alada','user_id' => '1','created_at' => '2019-08-11 05:17:44','updated_at' => '2019-08-11 05:17:44'),
  array('id' => '16','nombre_cientifico' => 'Abejas','nombre_comun' => 'Abejas','user_id' => '1','created_at' => '2019-08-29 03:10:45','updated_at' => '2019-08-29 03:10:45'),
  array('id' => '17','nombre_cientifico' => 'Grillo','nombre_comun' => 'Grillo','user_id' => '1','created_at' => '2019-08-29 03:17:32','updated_at' => '2019-08-29 03:17:32'),
  array('id' => '18','nombre_cientifico' => 'Tabano','nombre_comun' => 'Tabano','user_id' => '1','created_at' => '2019-09-12 09:05:13','updated_at' => '2019-09-12 09:05:13'),
  array('id' => '19','nombre_cientifico' => 'Blattella germanica','nombre_comun' => 'cucaracha alemana','user_id' => '1','created_at' => '2019-11-02 03:01:03','updated_at' => '2019-11-02 03:04:33'),
  array('id' => '20','nombre_cientifico' => 'Hormiga','nombre_comun' => 'Hormiga','user_id' => '1','created_at' => '2019-11-02 03:04:57','updated_at' => '2019-11-02 03:04:57'),
  array('id' => '21','nombre_cientifico' => 'Periplaneta americana','nombre_comun' => 'Cucaracha americana','user_id' => '1','created_at' => '2019-11-02 03:07:07','updated_at' => '2019-11-02 03:07:07'),
  array('id' => '22','nombre_cientifico' => 'Tityus serrulatus','nombre_comun' => 'Escorpion','user_id' => '1','created_at' => '2019-11-02 03:09:08','updated_at' => '2019-11-02 03:09:08'),
  array('id' => '23','nombre_cientifico' => 'Loxosceles sp','nombre_comun' => 'Araña','user_id' => '1','created_at' => '2019-11-02 03:10:16','updated_at' => '2019-11-02 03:10:16'),
  array('id' => '24','nombre_cientifico' => 'Ctenocephalides felis','nombre_comun' => 'Pulga','user_id' => '1','created_at' => '2019-11-02 03:11:12','updated_at' => '2019-11-02 03:11:12'),
  array('id' => '25','nombre_cientifico' => 'Cimex sp','nombre_comun' => 'Chinche de cama','user_id' => '1','created_at' => '2019-11-02 03:11:40','updated_at' => '2019-11-02 03:11:40'),
  array('id' => '26','nombre_cientifico' => 'Aedes aegypti','nombre_comun' => 'Mosquito','user_id' => '1','created_at' => '2019-11-02 03:12:48','updated_at' => '2019-11-02 03:12:48')
);
