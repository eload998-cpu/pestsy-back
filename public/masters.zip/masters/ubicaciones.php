<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`ubicaciones` */
$ubicaciones = array(
  array('id' => '3','ubicacion' => 'Pared','user_id' => '1','created_at' => '2020-09-09 13:58:52','updated_at' => '2020-09-09 13:58:52'),
  array('id' => '4','ubicacion' => 'Pared Planta','user_id' => '1','created_at' => '2020-09-09 13:59:07','updated_at' => '2020-09-09 13:59:07'),
  array('id' => '5','ubicacion' => 'Modulo#1','user_id' => '1','created_at' => '2020-09-09 14:02:30','updated_at' => '2020-09-09 14:02:30'),
  array('id' => '6','ubicacion' => 'Modulo#2','user_id' => '1','created_at' => '2020-09-09 14:02:40','updated_at' => '2020-09-09 14:02:40'),
  array('id' => '7','ubicacion' => 'Modulo#3','user_id' => '1','created_at' => '2020-09-09 14:02:50','updated_at' => '2020-09-09 14:02:50'),
  array('id' => '8','ubicacion' => 'Bajo Escaleras','user_id' => '1','created_at' => '2020-09-09 14:03:02','updated_at' => '2020-09-09 14:03:02'),
  array('id' => '9','ubicacion' => 'area de Granos','user_id' => '1','created_at' => '2020-09-09 14:03:11','updated_at' => '2020-09-09 14:03:11'),
  array('id' => '10','ubicacion' => 'Bodega de Cambios','user_id' => '1','created_at' => '2020-09-09 14:03:21','updated_at' => '2020-09-09 14:03:21'),
  array('id' => '11','ubicacion' => 'Bodega Verduras','user_id' => '1','created_at' => '2020-09-09 14:03:33','updated_at' => '2020-09-09 14:03:33'),
  array('id' => '12','ubicacion' => 'Maquinas','user_id' => '1','created_at' => '2020-09-09 14:03:42','updated_at' => '2020-09-09 14:03:42'),
  array('id' => '13','ubicacion' => 'Segundo Piso','user_id' => '1','created_at' => '2020-09-09 14:03:52','updated_at' => '2020-09-09 14:03:52'),
  array('id' => '14','ubicacion' => 'Oficinas','user_id' => '1','created_at' => '2020-09-09 14:04:05','updated_at' => '2020-09-09 14:04:05'),
  array('id' => '15','ubicacion' => 'Comedor Arriba','user_id' => '1','created_at' => '2020-09-09 14:04:13','updated_at' => '2020-09-09 14:04:13'),
  array('id' => '16','ubicacion' => 'Comedor Bajo','user_id' => '1','created_at' => '2020-09-09 14:04:27','updated_at' => '2020-09-09 14:04:27'),
  array('id' => '17','ubicacion' => 'Pasillos','user_id' => '1','created_at' => '2020-09-09 14:04:42','updated_at' => '2020-09-09 14:04:42'),
  array('id' => '18','ubicacion' => 'Bodega','user_id' => '1','created_at' => '2020-09-09 14:15:42','updated_at' => '2020-09-09 14:15:42'),
  array('id' => '19','ubicacion' => 'Bodega segunda planta Lavanderia','user_id' => '1','created_at' => '2020-09-09 14:15:55','updated_at' => '2020-09-09 14:15:55'),
  array('id' => '20','ubicacion' => 'Cocina','user_id' => '1','created_at' => '2020-09-09 14:16:04','updated_at' => '2020-09-09 14:16:04'),
  array('id' => '21','ubicacion' => 'Gas','user_id' => '1','created_at' => '2020-09-09 14:16:16','updated_at' => '2020-09-09 14:16:16'),
  array('id' => '23','ubicacion' => 'Zona Verde Interna','user_id' => '1','created_at' => '2020-09-09 14:16:45','updated_at' => '2020-09-09 14:16:45'),
  array('id' => '24','ubicacion' => 'Zona verde externa','user_id' => '1','created_at' => '2020-09-09 14:16:55','updated_at' => '2020-09-09 14:16:55'),
  array('id' => '25','ubicacion' => 'Bodega materiales','user_id' => '1','created_at' => '2020-09-09 14:17:05','updated_at' => '2020-09-09 14:17:05'),
  array('id' => '26','ubicacion' => 'Taller','user_id' => '1','created_at' => '2020-09-09 14:17:13','updated_at' => '2020-09-09 14:17:13'),
  array('id' => '27','ubicacion' => 'Servicios Sanitarios','user_id' => '1','created_at' => '2020-09-09 14:17:24','updated_at' => '2020-09-09 14:17:24'),
  array('id' => '29','ubicacion' => 'Reciclaje','user_id' => '1','created_at' => '2020-09-09 14:17:41','updated_at' => '2020-09-09 14:17:41')
);
