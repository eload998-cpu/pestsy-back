<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`aplicaciones` */
$aplicaciones = array(
  array('id' => '2','nombre' => 'Termonebulizacion','user_id' => '1','created_at' => '2019-01-30 21:34:15','updated_at' => '2019-01-30 21:34:15'),
  array('id' => '3','nombre' => 'Aspersion','user_id' => '1','created_at' => '2019-01-30 21:34:27','updated_at' => '2019-01-30 21:34:27'),
  array('id' => '4','nombre' => 'Nebulizacion en frio','user_id' => '1','created_at' => '2019-01-30 21:34:50','updated_at' => '2019-01-30 21:34:50'),
  array('id' => '5','nombre' => 'Gel','user_id' => '1','created_at' => '2019-01-30 21:34:58','updated_at' => '2019-01-30 21:34:58'),
  array('id' => '6','nombre' => 'Fumigacion en seco','user_id' => '1','created_at' => '2019-02-05 08:09:34','updated_at' => '2019-02-05 08:09:34'),
  array('id' => '7','nombre' => 'Granulado Zompopas','user_id' => '1','created_at' => '2019-05-31 01:15:20','updated_at' => '2019-05-31 01:15:20'),
  array('id' => '8','nombre' => 'Aerosol Ultra Bajo Volumen','user_id' => '1','created_at' => '2019-09-25 08:56:53','updated_at' => '2020-01-07 08:07:38'),
  array('id' => '14','nombre' => 'Cebo Insecticida Comestible','user_id' => '1','created_at' => '2020-10-21 03:19:34','updated_at' => '2020-10-21 03:19:34'),
  array('id' => '15','nombre' => 'Nebulizacion en frio (Ultra Bajo Volumen)','user_id' => '1','created_at' => '2021-07-09 01:55:39','updated_at' => '2021-07-09 01:55:39'),
  array('id' => '17','nombre' => 'Granulado','user_id' => '1','created_at' => '2022-06-27 02:03:29','updated_at' => '2022-06-27 02:03:29')
);
