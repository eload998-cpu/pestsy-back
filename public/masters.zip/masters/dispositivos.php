<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`dispositivos` */
$dispositivos = array(
  array('id' => '2','nombre' => 'Cebadero','user_id' => '1','created_at' => '2019-01-30 21:31:24','updated_at' => '2019-01-30 21:31:24'),
  array('id' => '3','nombre' => 'Trampa Tin Kat','user_id' => '1','created_at' => '2019-01-30 21:31:39','updated_at' => '2019-01-30 21:31:39'),
  array('id' => '4','nombre' => 'Desnucadora','user_id' => '1','created_at' => '2019-01-30 21:31:54','updated_at' => '2019-01-30 21:31:54'),
  array('id' => '5','nombre' => 'Gato de papel','user_id' => '1','created_at' => '2019-01-30 21:32:04','updated_at' => '2019-01-30 21:32:04'),
  array('id' => '6','nombre' => 'Tunel con lamina gomosa','user_id' => '1','created_at' => '2019-02-09 03:19:15','updated_at' => '2019-02-09 03:19:15'),
  array('id' => '7','nombre' => 'Trampa de Feromonas','user_id' => '1','created_at' => '2019-02-17 05:39:53','updated_at' => '2019-02-17 05:39:53'),
  array('id' => '10','nombre' => 'Trampa de captura viva','user_id' => '1','created_at' => '2019-05-06 18:52:32','updated_at' => '2019-05-06 18:52:32'),
  array('id' => '13','nombre' => 'Cebadero con trampa desnucadora','user_id' => '1','created_at' => '2020-03-17 23:29:24','updated_at' => '2020-03-17 23:29:24'),
  array('id' => '14','nombre' => 'Cebadero con lamina gomosa','user_id' => '1','created_at' => '2020-12-08 21:31:10','updated_at' => '2020-12-08 21:31:10'),
  array('id' => '15','nombre' => 'Cebadero','user_id' => '105','created_at' => '2020-12-18 19:11:36','updated_at' => '2020-12-18 19:11:36'),
  array('id' => '16','nombre' => 'Cebadero con trampa desnucadora','user_id' => '105','created_at' => '2020-12-18 19:11:50','updated_at' => '2020-12-18 19:11:50'),
  array('id' => '17','nombre' => 'Tunel con lamina gomosa','user_id' => '105','created_at' => '2020-12-18 19:12:04','updated_at' => '2020-12-18 19:12:04'),
  array('id' => '18','nombre' => 'Tubo PVC 3 pulgadas Cortado','user_id' => '1','created_at' => '2021-07-16 18:48:25','updated_at' => '2021-07-16 18:48:25'),
  array('id' => '19','nombre' => 'Cebadero interno','user_id' => '1','created_at' => '2021-07-21 00:22:20','updated_at' => '2021-07-21 00:22:20'),
  array('id' => '22','nombre' => 'Monitor de insectos con atrayente','user_id' => '1','created_at' => '2022-05-12 21:44:56','updated_at' => '2022-05-12 21:44:56'),
  array('id' => '23','nombre' => 'Tunel con Plancha Gomosa','user_id' => '1','created_at' => '2022-09-16 19:10:22','updated_at' => '2022-09-16 19:10:22')
);
