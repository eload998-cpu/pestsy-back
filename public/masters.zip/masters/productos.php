<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`productos` */
$productos = array(
  array('id' => '3','nombre' => 'Alpha plus','numero_de_registro' => 'Ggg546-54','ingrediente_activo' => 'Alphacypermetrina','user_id' => '1','created_at' => '2019-01-30 21:33:12','updated_at' => '2019-01-30 21:33:12'),
  array('id' => '4','nombre' => 'Storm','numero_de_registro' => '168615467','ingrediente_activo' => 'Flocoumafen','user_id' => '1','created_at' => '2019-01-30 21:33:34','updated_at' => '2021-07-15 16:56:17'),
  array('id' => '5','nombre' => 'Garden Top','numero_de_registro' => '665586','ingrediente_activo' => 'Cumarina','user_id' => '1','created_at' => '2019-02-05 22:30:06','updated_at' => '2019-02-05 22:30:29'),
  array('id' => '6','nombre' => 'Sin cebo, solo atrayente','numero_de_registro' => '7374+3+3','ingrediente_activo' => 'Sin cebo, solo atrayente','user_id' => '1','created_at' => '2019-02-06 04:59:46','updated_at' => '2019-02-06 04:59:46'),
  array('id' => '7','nombre' => 'Lamina gomosa','numero_de_registro' => 'No aplica','ingrediente_activo' => 'No aplica','user_id' => '1','created_at' => '2019-02-09 03:19:51','updated_at' => '2019-02-09 03:19:51'),
  array('id' => '8','nombre' => 'Feromonas','numero_de_registro' => '344343','ingrediente_activo' => 'Feromonas para polilla','user_id' => '1','created_at' => '2019-02-17 05:39:06','updated_at' => '2019-02-17 05:40:31'),
  array('id' => '9','nombre' => 'Dynamo','numero_de_registro' => '4113-P-613','ingrediente_activo' => 'Deltametrina - Permetrina','user_id' => '1','created_at' => '2019-02-23 05:57:50','updated_at' => '2019-02-23 05:57:50'),
  array('id' => '10','nombre' => 'Dragnet 36.8 EC','numero_de_registro' => 'US58-43-22-3373','ingrediente_activo' => 'Permetrina','user_id' => '1','created_at' => '2019-03-07 22:11:32','updated_at' => '2019-03-07 22:11:32'),
  array('id' => '11','nombre' => 'AL Star Dual 300 SC','numero_de_registro' => 'P-18-00015','ingrediente_activo' => 'Piretroide, NeoNicotinoide, Bifentrina, Imidacloprid','user_id' => '1','created_at' => '2019-04-26 01:53:20','updated_at' => '2019-04-26 01:53:20'),
  array('id' => '12','nombre' => 'Fendona 6SC','numero_de_registro' => '4116-P-140','ingrediente_activo' => 'Alfacipermetrina','user_id' => '1','created_at' => '2019-04-26 01:54:44','updated_at' => '2019-04-26 01:54:44'),
  array('id' => '13','nombre' => 'Al Star Dual 300SC + Fendona','numero_de_registro' => 'P-18-000150 / 4116-P-140','ingrediente_activo' => 'piretroide, Neonicotinoide, Bifentrina, Imidacloprid +Alfacipermetrina','user_id' => '1','created_at' => '2019-04-26 01:57:31','updated_at' => '2019-04-26 01:57:31'),
  array('id' => '14','nombre' => 'FASTRAC','numero_de_registro' => 'EPA-12455-95','ingrediente_activo' => 'Bromethalina 0.01%','user_id' => '1','created_at' => '2019-05-01 18:50:38','updated_at' => '2019-05-01 18:50:38'),
  array('id' => '15','nombre' => 'Cynoff WP 40','numero_de_registro' => '56576','ingrediente_activo' => 'Cipermetrina Piretroide','user_id' => '1','created_at' => '2019-05-08 07:20:58','updated_at' => '2019-05-08 07:21:43'),
  array('id' => '17','nombre' => 'Cynoff 25% EC','numero_de_registro' => '1005-P-025','ingrediente_activo' => 'Cipermetrina','user_id' => '1','created_at' => '2019-05-24 00:30:52','updated_at' => '2019-05-24 00:30:52'),
  array('id' => '18','nombre' => 'Riptide','numero_de_registro' => '1005-P-491','ingrediente_activo' => 'Piretrinas + Butoxido de piperonilo','user_id' => '1','created_at' => '2019-05-24 00:32:19','updated_at' => '2019-05-24 00:32:19'),
  array('id' => '19','nombre' => 'AGITA 10WG','numero_de_registro' => 'MAG  AT4-85-01-2292','ingrediente_activo' => 'Triametoxam + tricosene (atrayente)','user_id' => '1','created_at' => '2019-05-29 00:25:47','updated_at' => '2019-05-29 00:25:47'),
  array('id' => '20','nombre' => 'MIREX XS 0.3 GB','numero_de_registro' => '3762-1995','ingrediente_activo' => 'Organofluorina / Sulfluramid','user_id' => '1','created_at' => '2019-05-31 01:13:45','updated_at' => '2019-05-31 01:13:45'),
  array('id' => '21','nombre' => 'Vendetta','numero_de_registro' => '1021-1828','ingrediente_activo' => 'Abamectina','user_id' => '1','created_at' => '2019-08-01 07:36:19','updated_at' => '2019-08-01 07:36:19'),
  array('id' => '22','nombre' => 'Pluresto Pro','numero_de_registro' => 'P-18-00028','ingrediente_activo' => 'Pireteina+butoxido de piperonilo','user_id' => '1','created_at' => '2019-09-25 08:55:59','updated_at' => '2019-09-25 08:55:59'),
  array('id' => '26','nombre' => 'Sanivir( desinfectantes, bactericida, fungicida, viricida,)','numero_de_registro' => '180035','ingrediente_activo' => 'Glutaraldeido15%, Cloruro de DidecilDimetilAmonio10%','user_id' => '1','created_at' => '2020-04-04 21:44:37','updated_at' => '2020-08-22 06:46:43'),
  array('id' => '27','nombre' => 'Broditop 0.005','numero_de_registro' => '4858','ingrediente_activo' => 'Brodifacoum 0.005','user_id' => '1','created_at' => '2020-06-03 17:35:52','updated_at' => '2020-06-03 17:35:52'),
  array('id' => '28','nombre' => 'Tenopa','numero_de_registro' => 'BR26-85-1-5396','ingrediente_activo' => 'Alfacipermetrina, Flufenoxuron','user_id' => '1','created_at' => '2020-07-24 02:58:55','updated_at' => '2020-07-24 02:58:55'),
  array('id' => '29','nombre' => 'Maki Bloks (50 ppm)','numero_de_registro' => 'P-18-00022','ingrediente_activo' => 'Bromadiolona','user_id' => '1','created_at' => '2020-08-20 20:02:34','updated_at' => '2020-08-20 20:02:34'),
  array('id' => '30','nombre' => 'Ratigen','numero_de_registro' => '4113-P-845','ingrediente_activo' => 'Brodifacoum 0.005','user_id' => '1','created_at' => '2020-09-15 12:37:25','updated_at' => '2020-09-15 12:37:25')
);
