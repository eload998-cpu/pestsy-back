<?php
/**
 * Export to PHP Array plugin for PHPMyAdmin
 * @version 5.2.1
 */

/**
 * Database `migrupom_plagas`
 */

/* `migrupom_plagas`.`lugar_aplicaciones` */
$lugar_aplicaciones = array(
  array('id' => '2','nombre' => 'Sala','user_id' => '1','created_at' => '2019-01-30 21:35:10','updated_at' => '2019-01-30 21:35:10'),
  array('id' => '3','nombre' => 'Cocina','user_id' => '1','created_at' => '2019-01-30 21:35:16','updated_at' => '2019-01-30 21:35:16'),
  array('id' => '4','nombre' => 'Planta','user_id' => '1','created_at' => '2019-01-30 21:35:23','updated_at' => '2019-01-30 21:35:23'),
  array('id' => '5','nombre' => 'Granja','user_id' => '1','created_at' => '2019-01-30 21:35:28','updated_at' => '2019-01-30 21:35:28'),
  array('id' => '6','nombre' => 'Fabrica de concentrados, planta, parqueos, bodega y procesos, interno y externo','user_id' => '1','created_at' => '2019-02-02 04:49:14','updated_at' => '2019-02-02 04:49:14'),
  array('id' => '7','nombre' => 'Centro de Carnes interno y externo','user_id' => '1','created_at' => '2019-02-05 08:10:02','updated_at' => '2019-02-05 08:10:02'),
  array('id' => '8','nombre' => 'Restaurante interno y externo, cajas, muebles, camaras y otros.','user_id' => '1','created_at' => '2019-02-05 09:06:02','updated_at' => '2019-02-05 09:06:02'),
  array('id' => '9','nombre' => 'CEDI Centro de distribución y oficinas','user_id' => '1','created_at' => '2019-02-06 05:31:03','updated_at' => '2019-02-06 05:31:03'),
  array('id' => '10','nombre' => 'Comedores','user_id' => '1','created_at' => '2019-02-06 05:32:23','updated_at' => '2019-02-06 05:32:23'),
  array('id' => '11','nombre' => 'Comedor','user_id' => '1','created_at' => '2019-02-06 05:32:35','updated_at' => '2019-02-06 05:32:35'),
  array('id' => '12','nombre' => 'area externa, bodegas, reciclaje y jardines','user_id' => '1','created_at' => '2019-02-06 08:39:22','updated_at' => '2019-02-06 08:39:22'),
  array('id' => '13','nombre' => 'Restaurante externo y jardines','user_id' => '1','created_at' => '2019-02-06 10:05:54','updated_at' => '2019-02-06 10:05:54'),
  array('id' => '14','nombre' => 'Cocina de Feliz Foods','user_id' => '1','created_at' => '2019-02-07 04:44:26','updated_at' => '2019-02-07 04:44:26'),
  array('id' => '15','nombre' => 'Bodega y oficinas Feliz Foods','user_id' => '1','created_at' => '2019-02-07 05:11:48','updated_at' => '2019-02-07 05:11:48'),
  array('id' => '16','nombre' => 'Cafeteria, interno y externo, cajas, sillas, mesas, camaras, segunda planta, bodegas y otros.','user_id' => '1','created_at' => '2019-02-07 05:43:29','updated_at' => '2019-09-21 07:11:16'),
  array('id' => '17','nombre' => 'Supermercado, area externa, interna, segunda planta, bodegas, etc','user_id' => '1','created_at' => '2019-02-07 08:53:43','updated_at' => '2019-02-07 08:53:43'),
  array('id' => '18','nombre' => 'Planta de carnicos, lavanderia,  bodegas de condimentos, cartones, entre otros','user_id' => '1','created_at' => '2019-02-07 23:37:22','updated_at' => '2019-03-05 02:47:48'),
  array('id' => '19','nombre' => 'Perimetro de planta de Carnicos, bodega y area externa','user_id' => '1','created_at' => '2019-02-07 23:38:18','updated_at' => '2019-02-07 23:38:18'),
  array('id' => '20','nombre' => 'Oficinas, servicios sanitarios, bodegas internas, area de proceso','user_id' => '1','created_at' => '2019-02-07 23:38:54','updated_at' => '2019-02-07 23:38:54'),
  array('id' => '21','nombre' => 'Cabinas','user_id' => '1','created_at' => '2019-02-08 01:04:50','updated_at' => '2019-02-08 01:04:50'),
  array('id' => '22','nombre' => 'Restaurante, cocina y bar','user_id' => '1','created_at' => '2019-02-08 01:05:15','updated_at' => '2019-02-08 01:05:15'),
  array('id' => '23','nombre' => 'Restaurante, Bar, Cocina, bodegas, Basurero y area externa','user_id' => '1','created_at' => '2019-02-08 01:06:06','updated_at' => '2019-02-08 01:06:06'),
  array('id' => '24','nombre' => 'Bodega de frutas y verduras externo e interno','user_id' => '1','created_at' => '2019-02-08 04:05:29','updated_at' => '2019-02-08 04:05:29'),
  array('id' => '25','nombre' => 'Empacadora avicola (interna)','user_id' => '1','created_at' => '2019-02-09 03:18:18','updated_at' => '2019-02-09 03:18:18')
);
